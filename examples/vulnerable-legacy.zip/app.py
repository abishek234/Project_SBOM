import log4j
print('starting legacy app')